
java -cp config:lib/*:kafkalocal-1.0-SNAPSHOT.jar com.dataspark.kafkalocal.Application